from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapp import form
from myapp import models

# Create your views here.

def index(request):
    return render(request, 'home.html') 

def registro(request):
    return render(request, 'registro.html')

def ver_requerimientos(request):
    return render(request, 'ver_requerimientos.html')

def requerimientos(request):
    if request.method==('GET'):
        return render(request, 'requerimientos.html',{'formulario': form.CreateRequerimiento()})
    else:
        objetivo=request.POST['objetivo']
        regiones=request.POST['regiones']
        descripcion=request.POST['descripcion']
        models.Requerimiento.objects.create(objetivo=objetivo,descripcion=descripcion,regiones=regiones,estados=0)
        return redirect('ver_requerimientos')
    
def get_requerimiento(request):
    requerimiento=models.Requerimiento.objects.all()
    return render(request,'ver_requerimientos.html',{'Requerimiento': requerimiento})
