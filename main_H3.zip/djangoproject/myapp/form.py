from django import forms

class CreateRequerimiento(forms.Form):
    objetivo=forms.CharField(label='Objetivo principal',max_length=255)
    regiones=forms.CharField(label='Regiones involucradas',max_length=255)
    descripcion=forms.CharField(label='descripcion general',widget=forms.Textarea)