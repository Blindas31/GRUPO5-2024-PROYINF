from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapp import form
from myapp import models
from django.contrib.auth.decorators import login_required #Libreria para implementar inicio de sesion
from django.contrib.auth import logout
# Create your views here.

def index(request):
    return render(request, 'home.html') 

def registro(request):
    return render(request, 'registro.html')

@login_required #Marcar vista que requiere inicio de sesion
def ver_requerimientos(request):
    return render(request, 'ver_requerimientos.html')

@login_required #Marcar vista que requiere inicio de sesion
def requerimientos(request):
    if request.method==('GET'):
        return render(request, 'requerimientos.html',{'formulario': form.CreateRequerimiento()})
    else:
        objetivo=request.POST['objetivo']
        regiones=request.POST['regiones']
        descripcion=request.POST['descripcion']
        models.Requerimiento.objects.create(objetivo=objetivo,descripcion=descripcion,regiones=regiones,estados=0)
        return redirect('ver_requerimientos')

@login_required #Marcar vista que requiere inicio de sesion  
def get_requerimiento(request):
    requerimiento=models.Requerimiento.objects.all()
    return render(request,'ver_requerimientos.html',{'Requerimiento': requerimiento})

def cerrar_sesion(request):
    logout(request)
    return render(request,'home.html') 

def ver_boletines(request):
    boletines=models.Boletin.objects.all()
    return render(request,'ver_boletines.html',{'Boletin': boletines})

@login_required #Marcar vista que requiere inicio de sesion
def editar_boletines(request):
    boletines=models.Boletin.objects.all()
    if request.method==('GET'):
        return render(request,'editar_boletines.html',{'Boletin': boletines})    
    else:
        boletin_id=request.POST['boletin_id']
        boletin_estado=request.POST['boletin_estado']
        boletin_por_cambiar = models.Boletin.objects.get(id = boletin_id)
        boletin_por_cambiar.es_publico = boletin_estado
        boletin_por_cambiar.save()
        return redirect('editar_boletines')

@login_required #Marcar vista que requiere inicio de sesion  
def subir_boletines(request):
    if request.method==('GET'):
        return render(request,'subir_boletines.html',{'form': form.CreateBoletin()})
    else:
        boletin_titulo=request.POST['titulo']
        boletin_desc=request.POST['descripcion']
        boletin_arch = request.FILES.get('archivo_pdf')
        boletin_req = request.POST['requerimiento']
        Requimiento_vinculado = models.Requerimiento.objects.get(id = boletin_req)
        models.Boletin.objects.create(titulo = boletin_titulo,descripcion=boletin_desc,archivo_pdf=boletin_arch,requerimiento=Requimiento_vinculado)
        return redirect('index')
