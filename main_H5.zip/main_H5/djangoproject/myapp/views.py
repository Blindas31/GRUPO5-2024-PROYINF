from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapp import form
from myapp import models
from django.contrib.auth.decorators import login_required #Libreria para implementar inicio de sesion
from django.contrib.auth import logout
from django.http import JsonResponse
from .utils import *
from django.contrib.auth.models import User
from .permisos import *
# Create your views here.

def index(request):
    return render(request, 'home.html') 

def registro(request):
    return render(request, 'registro.html')

@login_required #Marcar vista que requiere inicio de sesion
def ver_requerimientos(request):
    return render(request, 'ver_requerimientos.html')

@login_required #Marcar vista que requiere inicio de sesion
def requerimientos(request):
    if request.method==('GET'):
        return render(request, 'requerimientos.html',{'formulario': form.CreateRequerimiento()})
    else:
        objetivo=request.POST['objetivo']
        regiones=request.POST['regiones']
        descripcion=request.POST['descripcion']
        dict ={}
        dict["Regiones"] = regiones
        dict["Objetivo"] = objetivo
        dict["Descripcion"] = descripcion
        return evaluar_insersion(request=request,Requerimientos_dict=dict)
        #models.Requerimiento.objects.create(objetivo=objetivo,descripcion=descripcion,regiones=regiones,estados=0)
        #return redirect('ver_requerimientos')

@login_required #Marcar vista que requiere inicio de sesion  
def get_requerimiento(request):
    cant_listo=models.Requerimiento.objects.filter(estados=1).count()
    cant_registrados=models.Requerimiento.objects.filter(estados=0).count()
    cant_pendientes=models.Requerimiento.objects.filter(estados=-1).count()
    requerimiento=models.Requerimiento.objects.all()
    return render(request,'ver_requerimientos.html',{'Requerimiento': requerimiento,"cant_listo":cant_listo,"cant_registrados":cant_registrados,"cant_pendientes":cant_pendientes})

def cerrar_sesion(request):
    logout(request)
    return render(request,'home.html') 

def ver_boletines(request):
    boletines=models.Boletin.objects.all()
    if request.method==('GET'):
        return render(request,'ver_boletines.html',{'Boletin': boletines})
    else:
        ver = int(request.POST['ver'])
        descargar = int(request.POST['descargar'])
        boletin_id = int(request.POST['boletin_id'])
        print("DESCARGAR",descargar)
        print("VER",ver)
        boletin = models.Boletin.objects.get(id = boletin_id)
        boletin.descargas = boletin.descargas + descargar
        boletin.vistas = boletin.vistas + ver
        boletin.save()
        pdf = boletin.archivo_pdf
        if descargar==1:
            with open(boletin.archivo_pdf.path, 'rb') as pdf:
                response = HttpResponse(pdf.read(), content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{boletin.archivo_pdf}.pdf"'
                return response
        if ver==1:
            with open(boletin.archivo_pdf.path, 'rb') as pdf:
                response = HttpResponse(pdf.read(), content_type='application/pdf')
                response['Content-Disposition'] = f'inline; filename="{boletin.archivo_pdf}.pdf"'
                return response
        
        return render(request,'ver_boletines.html',{'Boletin': models.Boletin.objects.all()})


@staff_required #Marcar vista que requiere estado staff
def editar_boletines(request):
    estados_requerimientos = ["Por procesar", "En proceso", "Finalizado"]
    boletines=models.Boletin.objects.all()
    if request.method==('GET'):
        return render(request,'editar_boletines.html',{'Boletin': boletines})    
    else:
        boletin_id=request.POST['boletin_id']
        lugar = int(request.POST['lugar'])
        if(lugar ==0):
            flag = int(request.POST['flag'])
            if flag==1:
                boletin = models.Boletin.objects.get(id = boletin_id)
                return render(request,'editar_boletines_aux.html',{'boletin_id': boletin_id, 'Boletin':boletin, 'requerimientos':models.Requerimiento.objects.all(),'mostrar':False, 'estados':estados_requerimientos})
            else:
                boletin_estado=request.POST['boletin_estado']
                boletin_por_cambiar = models.Boletin.objects.get(id = boletin_id)
                boletin_por_cambiar.es_publico = boletin_estado
                boletin_por_cambiar.save()
        else:
            eliminar = int(request.POST['eliminar'])
            print(eliminar)
            boletin = models.Boletin.objects.get(id = boletin_id)
            if eliminar == 1:
                print("ENTREEEEE")
                boletin.delete()
            else:
                mostrar = request.POST.get('mostrar')
                if int(mostrar) == 1:
                    tipo = request.POST.get('tipo')
                    if tipo == estados_requerimientos[0]: #LOS POR PROCESAR
                        requerimientos =  models.Requerimiento.objects.filter(estados=0)
                    elif tipo == estados_requerimientos[1]: #LOS EN PROCESO
                        requerimientos =  models.Requerimiento.objects.filter(estados=-1)
                    elif tipo == estados_requerimientos[2]: #LOS LISTOS
                        requerimientos =  models.Requerimiento.objects.filter(estados=1)
                    return render(request,'editar_boletines_aux.html',{'boletin_id': boletin_id, 'Boletin':boletin, 'requerimientos':requerimientos,'mostrar':True, 'estados':estados_requerimientos})
                titulo = request.POST.get('titulo')
                descripcion = request.POST.get('descripcion')
                archivo_pdf = request.FILES.get('archivo_pdf')
                requerimiento_id = request.POST.get('requerimiento')      
                if titulo:
                    boletin.titulo = titulo
                if descripcion:
                    boletin.descripcion = descripcion
                if archivo_pdf:
                    boletin.archivo_pdf = archivo_pdf
                if requerimiento_id:
                    boletin.requerimiento = models.Requerimiento.objects.get(id = requerimiento_id)
                boletin.save()
        return redirect('editar_boletines')

@staff_required #Marcar vista que requiere estado staff
def subir_boletines(request):
    if request.method==('GET'):
        return render(request,'subir_boletines.html',{'form': form.CreateBoletin()})
    else:
        boletin_titulo=request.POST['titulo']
        boletin_desc=request.POST['descripcion']
        boletin_arch = request.FILES.get('archivo_pdf')
        boletin_req = request.POST['requerimiento']
        Requimiento_vinculado = models.Requerimiento.objects.get(id = boletin_req)
        models.Boletin.objects.create(titulo = boletin_titulo,descripcion=boletin_desc,archivo_pdf=boletin_arch,requerimiento=Requimiento_vinculado)
        Requimiento_vinculado.estados = 1
        Requimiento_vinculado.save()        
        return redirect('index')

@staff_required #Marcar vista que requiere estado staff
def editar_requerimientos(request):
    requerimientos=models.Requerimiento.objects.all()
    if request.method==('GET'):
        return render(request,'editar_requerimientos.html',{'Requerimiento': requerimientos})    
    else:
        requerimiento_id=request.POST['requerimiento_id']
        requerimiento = models.Requerimiento.objects.get(id=requerimiento_id)
        if(int(request.POST["flag"]) == 1):
            print("entre")
            dict = {
                'Regiones':request.POST['Regiones'],
                'Objetivo':request.POST['Objetivo'],
                'Descripcion':request.POST['Descripcion'],
                'Id': request.POST['requerimiento_id']
            }
            return evaluar_modificacion(request = request, Requerimiento_dict = dict)
        else:
            if (int(request.POST["eliminar"])==1):
                requerimiento.delete()  
                return redirect('ver_requerimientos')
            else:
                requerimiento_editar_reg=int(request.POST['requerimiento_editar_reg'])
                requerimiento_editar_obj=int(request.POST['requerimiento_editar_obj'])
                requerimiento_editar_des=int(request.POST['requerimiento_editar_des'])
                return render(request, 'editar_requerimientos_aux.html', {'req_id':requerimiento_id,'editar_reg':requerimiento_editar_reg,'editar_obj':requerimiento_editar_obj,'editar_des':requerimiento_editar_des,'Requerimiento':requerimiento,'lugar':0})

@superuser_required #Marcar vista que requiere ser super usuario
def modificar_configuraciones(request):
    nombres = ["ACTIVACION_API_MAKE", "USUARIOS"] #Enumerar todas las opciones
    valores = [get_API_MAKE(), User.objects.all()] #Enumerar todos los valores que se quieren enviar al template
    dict = get_diccionario_nombre_valor(nombres,valores)
    if request.method==('GET'):
        return render(request,'modificar_configuraciones.html',dict)
    else:
        retornos = {}
        flag = int(request.POST["flag"])
        if flag == 0 : #Caso activacion de API
            retornos["ACTIVACION_API_MAKE"] = request.POST["opcion_ACTIVACION_API_MAKE"]

            if int(retornos["ACTIVACION_API_MAKE"]) == 0:
                set_API_MAKE(False)
                dict["ACTIVACION_API_MAKE"] = False
            if int(retornos["ACTIVACION_API_MAKE"]) == 1:
                set_API_MAKE(True)
                dict["ACTIVACION_API_MAKE"] = True
        elif flag == 1 : #Caso modificacion permisos de usuarios
            Staff = int(request.POST["Staff"])
            Activacion = int(request.POST["Activacion"])
            user_id = int(request.POST["user_id"])
            user = User.objects.get(id=user_id)
            if Activacion == -1: #Caso modificacion de staff
                if Staff ==1:
                    user.is_staff = True
                else:
                    user.is_staff = False
            else: #Caso modificacion de Activacion
                if Activacion == 1:
                    user.is_active = True
                else:
                    user.is_active = False
            user.save()
            dict["USUARIOS"] = User.objects.all()
        elif flag == -1 :
            requerimientos = models.Requerimiento.objects.all()
            boletines = models.Boletin.objects.all()
            for boletin in boletines:
                if boletin.requerimiento in requerimientos and boletin.requerimiento.estados != 1:
                    boletin.requerimiento.estados = 1
                    boletin.requerimiento.save()
            return redirect('ver_requerimientos')
        return render(request,'modificar_configuraciones.html',dict)

@staff_required #Marcar vista que requiere estado staff   
def estadisticas_boletines(request):
    cant_publicos=models.Boletin.objects.filter(es_publico = True).count()
    cant_ocultos=models.Boletin.objects.filter(es_publico = False).count()
    boletines = models.Boletin.objects.all()
    descargas_publicos = 0
    descargas_ocultos = 0 
    vistas_publicos =0
    vistas_ocultos =0
    for boletin in boletines:
        if boletin.es_publico:
            descargas_publicos = descargas_publicos + boletin.descargas
            vistas_publicos = vistas_publicos + boletin.vistas
        else:
            descargas_ocultos = descargas_ocultos + boletin.descargas
            vistas_ocultos = vistas_ocultos + boletin.vistas
    if(cant_publicos != 0):
        descargas_publicos=int(descargas_publicos/cant_publicos)
        vistas_publicos = int(vistas_publicos/cant_publicos)
    if(cant_ocultos !=0):
        descargas_ocultos=int(descargas_ocultos/cant_ocultos)
        vistas_ocultos=int(vistas_ocultos/cant_ocultos)
    dict ={
        'Boletines': boletines,
        'cant_publicos':cant_publicos,
        'cant_ocultos':cant_ocultos,
        'descargas_publicos':descargas_publicos,
        'vistas_publicos':vistas_publicos,
        'descargas_ocultos':descargas_ocultos,
        'vistas_ocultos':vistas_ocultos,
    }
    if request.method==('GET'):
        dict['mostrar']=0
        return render(request,'estadisticas_boletines.html',dict)
    else:
        dict['mostrar']=int(request.POST["mostrar"])
        return render(request,'estadisticas_boletines.html',dict)